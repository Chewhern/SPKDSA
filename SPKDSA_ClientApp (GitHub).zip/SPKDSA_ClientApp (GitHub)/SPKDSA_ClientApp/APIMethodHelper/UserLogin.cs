﻿using SPKDSA_ClientApp.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using SPKDSA_ClientApp.APIHelper;
using System.Runtime.InteropServices;
using System.IO;
using ASodium;
using BCASodium;

namespace SPKIML_EU_App.APIMethodHelper
{
    public static class UserLogin
    {
        public static String Login(String Contact)
        {
            String RegistrationAppRootFolder = "";
            String UserID = "";
            Byte[] AuthPrivateKey = new Byte[] { };
            if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows)) 
            {
                RegistrationAppRootFolder = AppContext.BaseDirectory + "\\Users\\";
                AuthPrivateKey = File.ReadAllBytes(RegistrationAppRootFolder + Contact + "\\PrivateKey.txt");
                UserID = File.ReadAllText(RegistrationAppRootFolder + Contact + "\\UserID.txt");
            }
            else 
            {
                RegistrationAppRootFolder = AppContext.BaseDirectory + "/Users/";
                AuthPrivateKey = File.ReadAllBytes(RegistrationAppRootFolder + Contact + "/PrivateKey.txt");
                UserID = File.ReadAllText(RegistrationAppRootFolder + Contact + "/UserID.txt");
            }
            Byte[] Challenge = UserGetChallenge.GetChallenge(UserID);
            Byte[] Signed_Challenge = new Byte[] { };
            if (AuthPrivateKey.Length == 64) 
            {
                Signed_Challenge = SodiumPublicKeyAuth.Sign(Challenge, AuthPrivateKey,true);
            }
            else
            {
                Signed_Challenge = SecureED448.GenerateSignatureMessage(AuthPrivateKey, Challenge, new Byte[] { }, true);
            }
            String Signed_ChallengeString = Convert.ToBase64String(Signed_Challenge);
            String StatusString = "";
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(APIIPAddressHelper.IPAddress);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                var response = client.GetAsync("UserOps/UserLogin?User_ID=" + UserID + "&SignedChallenge=" + HttpUtility.UrlEncode(Signed_ChallengeString));
                response.Wait();
                var result = response.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsStringAsync();
                    readTask.Wait();

                    var Result = readTask.Result;

                    StatusString = Result.Substring(1, Result.Length - 2);
                }
                else
                {
                    StatusString = "Error: Server encounter some issues";
                }
            }
            return StatusString;
        }
    }
}

﻿using System.Net.Http.Headers;
using System.Web;
using System;
using System.Net.Http;
using SPKDSA_ClientApp.Helper;

namespace SPKDSA_ClientApp.APIHelper
{
    public class UserGetChallenge
    {
        public static String StatusString = "";

        public static Byte[] GetChallenge(String User_ID) 
        {
            Byte[] Challenge = new Byte[] { };
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(APIIPAddressHelper.IPAddress);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                var response = client.GetAsync("UserChallenge?User_ID=" + User_ID);
                response.Wait();
                var result = response.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsStringAsync();
                    readTask.Wait();

                    var Result = readTask.Result;
                    Result = Result.Substring(1, Result.Length - 2);

                    if (Result.Contains("Error") == true)
                    {
                        StatusString = Result;
                    }
                    else
                    {
                        Challenge = Convert.FromBase64String(Result);
                    }
                }
                else
                {
                    StatusString="Error: Server encounter some issues";
                }
            }

            return Challenge;
        }
    }
}

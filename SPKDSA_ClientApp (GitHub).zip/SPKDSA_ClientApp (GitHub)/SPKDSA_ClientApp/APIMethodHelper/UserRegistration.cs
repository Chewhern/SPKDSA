﻿using Newtonsoft.Json;
using SPKDSA_ClientApp.Helper;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http.Headers;
using System.Net.Http;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace SPKDSA_ClientApp.APIMethodHelper
{
    public static class UserRegistration
    {
        public static String RegisterUser(String User_ID, String Auth_PK, String Contact) 
        {
            String StatusString = "";
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(APIIPAddressHelper.IPAddress);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(
                    new MediaTypeWithQualityHeaderValue("application/json"));
                var response = client.GetAsync("UserOps?User_ID=" + User_ID +"&Auth_PK=" + HttpUtility.UrlEncode(Auth_PK)+"&Contact="+HttpUtility.UrlEncode(Contact));
                response.Wait();
                var result = response.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsStringAsync();
                    readTask.Wait();

                    var Result = readTask.Result;

                    StatusString = Result.Substring(1, Result.Length - 2);
                }
                else
                {
                    StatusString = "Error: Server encounter some issues";
                }
            }
            return StatusString;
        }
    }
}

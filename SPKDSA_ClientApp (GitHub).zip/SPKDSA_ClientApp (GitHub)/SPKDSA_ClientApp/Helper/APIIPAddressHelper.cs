﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SPKDSA_ClientApp.Helper
{
    public static class APIIPAddressHelper
    {
        public static String? IPAddress { get; set; }

        public static Boolean HasSet { get; set; }
    }
}

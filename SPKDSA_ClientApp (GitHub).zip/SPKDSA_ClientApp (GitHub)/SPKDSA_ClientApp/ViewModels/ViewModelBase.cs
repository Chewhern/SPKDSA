﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace SPKDSA_ClientApp.ViewModels;

public class ViewModelBase : ObservableObject
{
}

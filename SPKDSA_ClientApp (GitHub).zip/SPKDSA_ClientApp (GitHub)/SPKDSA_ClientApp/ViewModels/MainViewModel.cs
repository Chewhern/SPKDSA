﻿namespace SPKDSA_ClientApp.ViewModels;

public partial class MainViewModel : ViewModelBase
{
}

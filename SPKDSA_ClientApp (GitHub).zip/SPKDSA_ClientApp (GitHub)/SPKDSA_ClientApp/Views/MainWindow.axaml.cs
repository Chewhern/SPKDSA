﻿using Avalonia.Controls;

namespace SPKDSA_ClientApp.Views;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }
}

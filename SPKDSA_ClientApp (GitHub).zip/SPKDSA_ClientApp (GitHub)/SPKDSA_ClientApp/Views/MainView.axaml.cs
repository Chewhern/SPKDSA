﻿using ASodium;
using Avalonia.Controls;
using Avalonia.Media;
using BCASodium;
using SPKDSA_ClientApp.APIMethodHelper;
using SPKDSA_ClientApp.Helper;
using SPKIML_EU_App.APIMethodHelper;
using System;
using System.IO;
using System.Runtime.InteropServices;

namespace SPKDSA_ClientApp.Views;

public partial class MainView : UserControl
{
    private static int ServerOpsAppUIChooser = 0;
    private static int RegistrationAppUIChooser = 0;
    private static int LoginAppUIChooser = 0;
    private static TextBlock[] FirstServerOpsAppTextBlockArray = new TextBlock[] { };
    private static TextBox[] FirstServerOpsAppTextBoxArray = new TextBox[] { };
    private static Button[] FirstServerOpsAppButtonArray = new Button[] { };
    private static TextBlock[] FirstRegistrationAppTextBlockArray = new TextBlock[] { };
    private static TextBox[] FirstRegistrationAppTextBoxArray = new TextBox[] { };
    private static RadioButton[] FirstRegistrationAppRadioButtonArray = new RadioButton[] { };
    private static Button[] FirstRegistrationAppButtonArray = new Button[] { };
    private static TextBlock[] FirstLoginAppTextBlockArray = new TextBlock[] { };
    private static TextBox[] FirstLoginAppTextBoxArray = new TextBox[] { };
    private static Button[] FirstLoginAppButtonArray = new Button[] { };
    private static TextBlock[] SecondLoginAppTextBlockArray = new TextBlock[] { };
    private static TextBox[] SecondLoginAppTextBoxArray = new TextBox[] { };
    private static Button[] SecondLoginAppButtonArray = new Button[] { };
    private static Boolean HasServerOpsAppUIRendered = false;
    private static Boolean HasRegistrationAppUIRendered = false;
    private static Boolean HasLoginAppUIRendered = false;
    private static String ServerOpsAppRootFolder = "";
    private static String UserOpsRootFolder = "";

    public MainView()
    {
        InitializeComponent();
        ServerOpsAppInitialization();
        RegistrationAppInitialization();
        LoginAppInitialization();
        if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
        {
            ServerOpsAppRootFolder = AppContext.BaseDirectory + "\\ServerIP\\";
            UserOpsRootFolder = AppContext.BaseDirectory + "\\Users\\";
        }
        else
        {
            ServerOpsAppRootFolder = AppContext.BaseDirectory + "/ServerIP/";
            UserOpsRootFolder = AppContext.BaseDirectory + "/Users/";
        }
        if (Directory.Exists(ServerOpsAppRootFolder) == false)
        {
            Directory.CreateDirectory(ServerOpsAppRootFolder);
        }
        if (Directory.Exists(UserOpsRootFolder) == false)
        {
            Directory.CreateDirectory(UserOpsRootFolder);
        }
        StartupFunction();
    }

    private void StartupFunction() 
    {
        if (Directory.Exists(ServerOpsAppRootFolder) == true)
        {
            if (File.Exists(ServerOpsAppRootFolder + "IP.txt") == true)
            {
                EstablishConnectionHelper.CreateLinkWithServer();
                ServerIPStatusTB.Text = EstablishConnectionHelper.ConnectionStatus;
            }
        }
    }

    private void ServerOpsAppInitialization() 
    {
        ServerOpsAppUIChooser = 0;
        ServerOpsAppToggleBTN1.IsCheckedChanged += ServerOpsAppToggleBTNsFunction;
    }

    private void RegistrationAppInitialization() 
    {
        RegistrationAppUIChooser = 0;
        RegistrationAppToggleBTN1.IsCheckedChanged += RegistrationAppToggleBTNsFunction;
    }

    private void LoginAppInitialization() 
    {
        LoginAppUIChooser = 0;
        LoginAppToggleBTN1.IsCheckedChanged += LoginAppToggleBTNsFunction;
        LoginAppToggleBTN2.IsCheckedChanged += LoginAppToggleBTNsFunction;
    }

    private void ServerOpsAppToggleBTNsFunction(object? sender, Avalonia.Interactivity.RoutedEventArgs e) 
    {
        if(ServerOpsAppToggleBTN1.IsChecked == true) 
        {
            ServerOpsAppUIChooser = 1;
        }
        else 
        {
            ServerOpsAppResetUI();
        }
        ServerOpsAppDrawUI();
    }

    private void RegistrationAppToggleBTNsFunction(object? sender, Avalonia.Interactivity.RoutedEventArgs e)
    {
        if(RegistrationAppToggleBTN1.IsChecked == true) 
        {
            RegistrationAppUIChooser = 1;
        }
        else 
        {
            RegistrationAppResetUI();
        }
        RegistrationAppDrawUI();
    }

    private void LoginAppToggleBTNsFunction(object? sender, Avalonia.Interactivity.RoutedEventArgs e)
    {
        if(LoginAppToggleBTN1.IsChecked == true) 
        {
            LoginAppUIChooser = 1;
            LoginAppToggleBTN2.IsChecked = false;
        }
        else if(LoginAppToggleBTN2.IsChecked == true) 
        {
            LoginAppUIChooser = 2;
            LoginAppToggleBTN1.IsChecked = false;
        }
        else
        {
            LoginAppResetUI();
        }
        LoginAppDrawUI();
    }

    private void ServerOpsAppDrawUI() 
    {
        if(ServerOpsAppUIChooser == 1) 
        {
            if(HasServerOpsAppUIRendered == false) 
            {
                FirstServerOpsAppTextBlockArray = new TextBlock[2];
                FirstServerOpsAppTextBlockArray[0] = new TextBlock();
                FirstServerOpsAppTextBlockArray[1] = new TextBlock();
                FirstServerOpsAppTextBlockArray[0].Text = "Server API IP address of SPKDSA?";
                FirstServerOpsAppTextBlockArray[1].Text = "Server connection status (Read Only)";
                FirstServerOpsAppTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstServerOpsAppTextBoxArray = new TextBox[2];
                FirstServerOpsAppTextBoxArray[0] = new TextBox();
                FirstServerOpsAppTextBoxArray[1] = new TextBox();
                FirstServerOpsAppTextBoxArray[0].Height = 125;
                FirstServerOpsAppTextBoxArray[0].MaxHeight = 125;
                FirstServerOpsAppTextBoxArray[0].Width = 250;
                FirstServerOpsAppTextBoxArray[0].MaxWidth = 250;
                FirstServerOpsAppTextBoxArray[1].Height = 125;
                FirstServerOpsAppTextBoxArray[1].MaxHeight = 125;
                FirstServerOpsAppTextBoxArray[1].Width = 250;
                FirstServerOpsAppTextBoxArray[1].MaxWidth = 250;
                FirstServerOpsAppTextBoxArray[0].TextWrapping = TextWrapping.Wrap;
                FirstServerOpsAppTextBoxArray[1].TextWrapping = TextWrapping.Wrap;
                FirstServerOpsAppTextBoxArray[1].IsReadOnly = true;
                FirstServerOpsAppButtonArray = new Button[1];
                FirstServerOpsAppButtonArray[0] = new Button();
                FirstServerOpsAppButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstServerOpsAppButtonArray[0].Content = "Add and establish a connection";
                FirstServerOpsAppButtonArray[0].Click += ServerOpsAppBTN_Click;
                ServerOpsAppLowerRightLPSP.Children.Add(FirstServerOpsAppTextBlockArray[0]);
                ServerOpsAppLowerRightLPSP.Children.Add(FirstServerOpsAppTextBoxArray[0]);
                ServerOpsAppLowerRightLPSP.Children.Add(FirstServerOpsAppTextBlockArray[1]);
                ServerOpsAppLowerRightLPSP.Children.Add(FirstServerOpsAppTextBoxArray[1]);
                ServerOpsAppLowerRightLPSP.Children.Add(FirstServerOpsAppButtonArray[0]);
                HasServerOpsAppUIRendered = true;
            }
        }
        else 
        {
            ServerOpsAppResetUI();
        }
    }

    private void RegistrationAppDrawUI() 
    {
        if(RegistrationAppUIChooser == 1) 
        {
            if (HasRegistrationAppUIRendered == false) 
            {
                FirstRegistrationAppTextBlockArray = new TextBlock[5];
                FirstRegistrationAppTextBlockArray[0] = new TextBlock();
                FirstRegistrationAppTextBlockArray[1] = new TextBlock();
                FirstRegistrationAppTextBlockArray[2] = new TextBlock();
                FirstRegistrationAppTextBlockArray[3] = new TextBlock();
                FirstRegistrationAppTextBlockArray[4] = new TextBlock();
                FirstRegistrationAppTextBlockArray[0].Text = "User ID (Read Only)";
                FirstRegistrationAppTextBlockArray[1].Text = "Contact (Email/Phone Number)";
                FirstRegistrationAppTextBlockArray[2].Text = "Auth PK (Read Only)";
                FirstRegistrationAppTextBlockArray[3].Text = "What's the DSA?";
                FirstRegistrationAppTextBlockArray[4].Text = "Server Status (Read Only)";
                FirstRegistrationAppTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstRegistrationAppTextBlockArray[2].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstRegistrationAppTextBlockArray[3].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstRegistrationAppTextBlockArray[4].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstRegistrationAppTextBoxArray = new TextBox[4];
                FirstRegistrationAppTextBoxArray[0] = new TextBox();
                FirstRegistrationAppTextBoxArray[1] = new TextBox();
                FirstRegistrationAppTextBoxArray[2] = new TextBox();
                FirstRegistrationAppTextBoxArray[3] = new TextBox();
                FirstRegistrationAppTextBoxArray[0].IsReadOnly = true;
                FirstRegistrationAppTextBoxArray[2].IsReadOnly = true;
                FirstRegistrationAppTextBoxArray[3].IsReadOnly = true;
                FirstRegistrationAppTextBoxArray[0].Width = 250;
                FirstRegistrationAppTextBoxArray[0].MaxWidth = 250;
                FirstRegistrationAppTextBoxArray[1].Width = 250;
                FirstRegistrationAppTextBoxArray[1].MaxWidth = 250;
                FirstRegistrationAppTextBoxArray[2].Width = 250;
                FirstRegistrationAppTextBoxArray[2].MaxWidth = 250;
                FirstRegistrationAppTextBoxArray[3].Width = 250;
                FirstRegistrationAppTextBoxArray[3].MaxWidth = 250;
                FirstRegistrationAppTextBoxArray[0].Height = 125;
                FirstRegistrationAppTextBoxArray[0].MaxHeight = 125;
                FirstRegistrationAppTextBoxArray[1].Height = 125;
                FirstRegistrationAppTextBoxArray[1].MaxHeight = 125;
                FirstRegistrationAppTextBoxArray[2].Height = 125;
                FirstRegistrationAppTextBoxArray[2].MaxHeight = 125;
                FirstRegistrationAppTextBoxArray[3].Height = 125;
                FirstRegistrationAppTextBoxArray[3].MaxHeight = 125;
                FirstRegistrationAppTextBoxArray[0].TextWrapping = TextWrapping.Wrap;
                FirstRegistrationAppTextBoxArray[1].TextWrapping = TextWrapping.Wrap;
                FirstRegistrationAppTextBoxArray[2].TextWrapping = TextWrapping.Wrap;
                FirstRegistrationAppTextBoxArray[3].TextWrapping = TextWrapping.Wrap;
                FirstRegistrationAppTextBoxArray[0].HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Left;
                FirstRegistrationAppTextBoxArray[1].HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Left;
                FirstRegistrationAppTextBoxArray[2].HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Left;
                FirstRegistrationAppRadioButtonArray = new RadioButton[2];
                FirstRegistrationAppRadioButtonArray[0] = new RadioButton();
                FirstRegistrationAppRadioButtonArray[1] = new RadioButton();
                FirstRegistrationAppRadioButtonArray[0].GroupName = "CurveTypes";
                FirstRegistrationAppRadioButtonArray[0].Content = "Curve25519 - ED25519 (Stable)";
                FirstRegistrationAppRadioButtonArray[0].IsChecked = true;
                FirstRegistrationAppRadioButtonArray[1].GroupName = "CurveTypes";
                FirstRegistrationAppRadioButtonArray[1].Content = "Curve448 - ED448 (Experimental)";
                FirstRegistrationAppButtonArray = new Button[1];
                FirstRegistrationAppButtonArray[0] = new Button();
                FirstRegistrationAppButtonArray[0].Content = "Register Account";
                FirstRegistrationAppButtonArray[0].Click += RegistrationAppBTN_Click;
                FirstRegistrationAppButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                ScrollViewer MyScrollViewer = new ScrollViewer();
                MyScrollViewer.MaxHeight = 700;
                MyScrollViewer.Width = 310;
                StackPanel MyStackPanel = new StackPanel();
                MyStackPanel.Orientation = Avalonia.Layout.Orientation.Vertical;
                MyStackPanel.HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Left;
                MyStackPanel.Children.Add(FirstRegistrationAppTextBlockArray[0]);
                MyStackPanel.Children.Add(FirstRegistrationAppTextBoxArray[0]);
                MyStackPanel.Children.Add(FirstRegistrationAppTextBlockArray[1]);
                MyStackPanel.Children.Add(FirstRegistrationAppTextBoxArray[1]);
                MyStackPanel.Children.Add(FirstRegistrationAppTextBlockArray[2]);
                MyStackPanel.Children.Add(FirstRegistrationAppTextBoxArray[2]);
                MyStackPanel.Children.Add(FirstRegistrationAppTextBlockArray[3]);
                MyStackPanel.Children.Add(FirstRegistrationAppRadioButtonArray[0]);
                MyStackPanel.Children.Add(FirstRegistrationAppRadioButtonArray[1]);
                MyStackPanel.Children.Add(FirstRegistrationAppTextBlockArray[4]);
                MyStackPanel.Children.Add(FirstRegistrationAppTextBoxArray[3]);
                MyStackPanel.Children.Add(FirstRegistrationAppButtonArray[0]);
                MyScrollViewer.Content = MyStackPanel;
                MyScrollViewer.VerticalScrollBarVisibility = Avalonia.Controls.Primitives.ScrollBarVisibility.Auto;
                RegistrationAppLowerRightSP.Children.Add(MyScrollViewer);
                HasRegistrationAppUIRendered = true;
            }
        }
        else 
        {
            RegistrationAppResetUI();
        }
    }

    private void LoginAppDrawUI() 
    {
        if (LoginAppUIChooser == 1) 
        {
            if (HasLoginAppUIRendered == false) 
            {
                FirstLoginAppTextBlockArray = new TextBlock[2];
                FirstLoginAppTextBlockArray[0] = new TextBlock();
                FirstLoginAppTextBlockArray[1] = new TextBlock();
                FirstLoginAppTextBlockArray[0].Text = "Contact?";
                FirstLoginAppTextBlockArray[1].Text = "Login Status (Read Only)";
                FirstLoginAppTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                FirstLoginAppTextBoxArray = new TextBox[2];
                FirstLoginAppTextBoxArray[0] = new TextBox();
                FirstLoginAppTextBoxArray[1] = new TextBox();
                FirstLoginAppTextBoxArray[1].IsReadOnly = true;
                FirstLoginAppTextBoxArray[0].Width = 250;
                FirstLoginAppTextBoxArray[0].MaxWidth = 250;
                FirstLoginAppTextBoxArray[0].Height = 100;
                FirstLoginAppTextBoxArray[0].MaxHeight = 100;
                FirstLoginAppTextBoxArray[1].Width = 250;
                FirstLoginAppTextBoxArray[1].MaxWidth = 250;
                FirstLoginAppTextBoxArray[1].Height = 100;
                FirstLoginAppTextBoxArray[1].MaxHeight = 100;
                FirstLoginAppTextBoxArray[0].TextWrapping = TextWrapping.Wrap;
                FirstLoginAppTextBoxArray[1].TextWrapping = TextWrapping.Wrap;
                FirstLoginAppButtonArray = new Button[1];
                FirstLoginAppButtonArray[0] = new Button();
                FirstLoginAppButtonArray[0].Content = "Login";
                FirstLoginAppButtonArray[0].Click += LoginAppBTN_Click;
                FirstLoginAppButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                LoginAppLowerRightSP.Children.Add(FirstLoginAppTextBlockArray[0]);
                LoginAppLowerRightSP.Children.Add(FirstLoginAppTextBoxArray[0]);
                LoginAppLowerRightSP.Children.Add(FirstLoginAppTextBlockArray[1]);
                LoginAppLowerRightSP.Children.Add(FirstLoginAppTextBoxArray[1]);
                LoginAppLowerRightSP.Children.Add(FirstLoginAppButtonArray[0]);
                HasLoginAppUIRendered = true;
            }
        }
        else if(LoginAppUIChooser == 2) 
        {
            if(HasLoginAppUIRendered == false) 
            {
                SecondLoginAppTextBlockArray = new TextBlock[3];
                SecondLoginAppTextBlockArray[0] = new TextBlock();
                SecondLoginAppTextBlockArray[1] = new TextBlock();
                SecondLoginAppTextBlockArray[2] = new TextBlock();
                SecondLoginAppTextBlockArray[0].Text = "Contact?";
                SecondLoginAppTextBlockArray[1].Text = "Reset Status (Read Only)";
                SecondLoginAppTextBlockArray[2].Text = "In actual production, developers might remove the user id" + Environment.NewLine +
                    "and just use the contact as username or user ID." + Environment.NewLine +
                    "The contact here mainly refers to something like" + Environment.NewLine +
                    "email or phone numbers (most common)" + Environment.NewLine +
                    "The usual email recovery can be applied here.";
                SecondLoginAppTextBlockArray[1].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondLoginAppTextBlockArray[2].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                SecondLoginAppTextBoxArray = new TextBox[2];
                SecondLoginAppTextBoxArray[0] = new TextBox();
                SecondLoginAppTextBoxArray[1] = new TextBox();
                SecondLoginAppTextBoxArray[1].IsReadOnly = true;
                SecondLoginAppTextBoxArray[0].Width = 250;
                SecondLoginAppTextBoxArray[0].MaxWidth = 250;
                SecondLoginAppTextBoxArray[0].Height = 100;
                SecondLoginAppTextBoxArray[0].MaxHeight = 100;
                SecondLoginAppTextBoxArray[1].Width = 250;
                SecondLoginAppTextBoxArray[1].MaxWidth = 250;
                SecondLoginAppTextBoxArray[1].Height = 100;
                SecondLoginAppTextBoxArray[1].MaxHeight = 100;
                SecondLoginAppTextBoxArray[0].TextWrapping = TextWrapping.Wrap;
                SecondLoginAppTextBoxArray[1].TextWrapping = TextWrapping.Wrap;
                SecondLoginAppTextBoxArray[0].HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Left;
                SecondLoginAppTextBoxArray[1].HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Left;
                SecondLoginAppButtonArray = new Button[1];
                SecondLoginAppButtonArray[0] = new Button();
                SecondLoginAppButtonArray[0].Content = "Reset public key (Dummy)";
                SecondLoginAppButtonArray[0].Click += LoginAppBTN_Click;
                SecondLoginAppButtonArray[0].Margin = Avalonia.Thickness.Parse("0, 10, 0, 0");
                LoginAppLowerRightSP.HorizontalAlignment = Avalonia.Layout.HorizontalAlignment.Left;
                LoginAppLowerRightSP.Children.Add(SecondLoginAppTextBlockArray[0]);
                LoginAppLowerRightSP.Children.Add(SecondLoginAppTextBoxArray[0]);
                LoginAppLowerRightSP.Children.Add(SecondLoginAppTextBlockArray[1]);
                LoginAppLowerRightSP.Children.Add(SecondLoginAppTextBoxArray[1]);
                LoginAppLowerRightSP.Children.Add(SecondLoginAppButtonArray[0]);
                LoginAppLowerRightSP.Children.Add(SecondLoginAppTextBlockArray[2]);
                HasLoginAppUIRendered = true;
            }
        }
        else 
        {
            LoginAppResetUI();
        }
    }

    private void ServerOpsAppResetUI() 
    {
        HasServerOpsAppUIRendered = false;
        ServerOpsAppUIChooser = 0;
        FirstServerOpsAppTextBlockArray = new TextBlock[] { };
        FirstServerOpsAppTextBoxArray = new TextBox[] { };
        FirstServerOpsAppButtonArray = new Button[] { };
        ServerOpsAppLowerRightLPSP.Children.Clear();
    }

    private void RegistrationAppResetUI() 
    {
        HasRegistrationAppUIRendered = false;
        RegistrationAppUIChooser = 0;
        FirstRegistrationAppTextBlockArray = new TextBlock[] { };
        FirstRegistrationAppTextBoxArray = new TextBox[] { };
        FirstRegistrationAppRadioButtonArray = new RadioButton[] { };
        FirstRegistrationAppButtonArray = new Button[] { };
        RegistrationAppLowerRightSP.Children.Clear();
    }

    private void LoginAppResetUI() 
    {
        HasLoginAppUIRendered = false;
        LoginAppUIChooser = 0;
        FirstLoginAppTextBlockArray = new TextBlock[] { };
        FirstLoginAppTextBoxArray = new TextBox[] { };
        FirstLoginAppButtonArray = new Button[] { };
        SecondLoginAppTextBlockArray = new TextBlock[] { };
        SecondLoginAppTextBoxArray = new TextBox[] { };
        SecondLoginAppButtonArray = new Button[] { };
        LoginAppLowerRightSP.Children.Clear();
    }

    private void ServerOpsAppBTN_Click(object? sender, Avalonia.Interactivity.RoutedEventArgs e) 
    {
        if (ServerOpsAppUIChooser == 1) 
        {
            String IPAddress = FirstServerOpsAppTextBoxArray[0].Text;
            if (IPAddress != null && IPAddress.CompareTo("") != 0)
            {
                if (File.Exists(ServerOpsAppRootFolder + "IP.txt") == true)
                {
                    ServerIPStatusTB.Text = "";
                }
                File.WriteAllText(ServerOpsAppRootFolder + "IP.txt", IPAddress);
                EstablishConnectionHelper.CreateLinkWithServer();
                ServerIPStatusTB.Text = EstablishConnectionHelper.ConnectionStatus;
                FirstServerOpsAppTextBoxArray[1].Text = EstablishConnectionHelper.ConnectionStatus;
            }
        }
    }

    private void RegistrationAppBTN_Click(object? sender, Avalonia.Interactivity.RoutedEventArgs e) 
    {
        if(RegistrationAppUIChooser == 1) 
        {
            String Contact = FirstRegistrationAppTextBoxArray[1].Text;
            String AuthenticationPublicKeyB64String = "";
            String User_ID = CryptographicSecureIDGenerator.GenerateMinimumAmountOfUniqueString(32);
            if(Contact!=null && Contact.CompareTo("") != 0) 
            {
                if (Directory.Exists(UserOpsRootFolder + Contact) == false)
                {
                    Directory.CreateDirectory(UserOpsRootFolder + Contact);
                    if (User_ID.Length > 32)
                    {
                        User_ID = User_ID.Substring(0, 32);
                    }
                    if (FirstRegistrationAppRadioButtonArray[0].IsChecked == true)
                    {
                        RevampedKeyPair MyAuthenticationKeyPair = SodiumPublicKeyAuth.GenerateRevampedKeyPair();
                        if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
                        {
                            File.WriteAllBytes(UserOpsRootFolder + Contact + "\\PrivateKey.txt", MyAuthenticationKeyPair.PrivateKey);
                            File.WriteAllBytes(UserOpsRootFolder + Contact + "\\PublicKey.txt", MyAuthenticationKeyPair.PublicKey);
                            File.WriteAllText(UserOpsRootFolder + Contact + "\\AlgorithmType.txt", "ED25519");
                            File.WriteAllText(UserOpsRootFolder + Contact + "\\UserID.txt", User_ID);
                        }
                        else
                        {
                            File.WriteAllBytes(UserOpsRootFolder + Contact + "/PrivateKey.txt", MyAuthenticationKeyPair.PrivateKey);
                            File.WriteAllBytes(UserOpsRootFolder + Contact + "/PublicKey.txt", MyAuthenticationKeyPair.PublicKey);
                            File.WriteAllText(UserOpsRootFolder + Contact + "/AlgorithmType.txt", "ED25519");
                            File.WriteAllText(UserOpsRootFolder + Contact + "/UserID.txt", User_ID);
                        }
                        AuthenticationPublicKeyB64String = Convert.ToBase64String(MyAuthenticationKeyPair.PublicKey);
                        MyAuthenticationKeyPair.Clear();
                    }
                    else
                    {
                        ED448RevampedKeyPair MyAuthenticationKeyPair = SecureED448.GenerateED448RevampedKeyPair();
                        if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
                        {
                            File.WriteAllBytes(UserOpsRootFolder + Contact + "\\PrivateKey.txt", MyAuthenticationKeyPair.PrivateKey);
                            File.WriteAllBytes(UserOpsRootFolder + Contact + "\\PublicKey.txt", MyAuthenticationKeyPair.PublicKey);
                            File.WriteAllText(UserOpsRootFolder + Contact + "\\AlgorithmType.txt", "ED25519");
                            File.WriteAllText(UserOpsRootFolder + Contact + "\\UserID.txt", User_ID);
                        }
                        else
                        {
                            File.WriteAllBytes(UserOpsRootFolder + Contact + "/PrivateKey.txt", MyAuthenticationKeyPair.PrivateKey);
                            File.WriteAllBytes(UserOpsRootFolder + Contact + "/PublicKey.txt", MyAuthenticationKeyPair.PublicKey);
                            File.WriteAllText(UserOpsRootFolder + Contact + "/AlgorithmType.txt", "ED25519");
                            File.WriteAllText(UserOpsRootFolder + Contact + "/UserID.txt", User_ID);
                        }
                        AuthenticationPublicKeyB64String = Convert.ToBase64String(MyAuthenticationKeyPair.PublicKey);
                        MyAuthenticationKeyPair.Clear();
                    }
                    FirstRegistrationAppTextBoxArray[0].Text = User_ID;
                    FirstRegistrationAppTextBoxArray[2].Text = AuthenticationPublicKeyB64String;
                    FirstRegistrationAppTextBoxArray[3].Text = UserRegistration.RegisterUser(User_ID, AuthenticationPublicKeyB64String, Contact);
                }
                else
                {
                    FirstRegistrationAppTextBoxArray[3].Text = "Error: This user existed..";
                }
            }
            else 
            {
                FirstRegistrationAppTextBoxArray[3].Text = "Error: Contact must not be empty/null";
            }
        }
    }

    private void LoginAppBTN_Click(object? sender, Avalonia.Interactivity.RoutedEventArgs e) 
    {
        if(LoginAppUIChooser == 1) 
        {
            String Contact = FirstLoginAppTextBoxArray[0].Text;
            if(Contact!=null && Contact.CompareTo("") != 0) 
            {
                FirstLoginAppTextBoxArray[1].Text = UserLogin.Login(Contact);
            }
            else 
            {
                FirstLoginAppTextBoxArray[1].Text = "Error: Contact must not be empty/null";
            }
        }
    }
}

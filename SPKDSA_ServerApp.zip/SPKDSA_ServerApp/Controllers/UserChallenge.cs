﻿using ASodium;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;
using SPKDSA_ServerApp.Helper;

namespace SPKDSA_ServerApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserChallenge : ControllerBase
    {
        private static MyOwnMySQLConnection myMyOwnMySQLConnection = new MyOwnMySQLConnection();

        [HttpGet]
        public String GenerateOrGetChallenge(String User_ID)
        {
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            String ExceptionString = "";
            int Count = 0;
            String ResultString = "";
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `Users` WHERE `User_ID`=@User_ID";
            MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
            if (Count > 0)
            {
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `User_Challenge` WHERE `User_ID`=@User_ID";
                MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                Byte[] Challenge = new Byte[] { };
                DateTime CurrentDateTime = DateTime.UtcNow.AddHours(8);
                DateTime DatabaseDateTime = new DateTime();
                TimeSpan MyTimeSpan = new TimeSpan();
                if (Count == 0)
                {
                    Challenge = SodiumRNG.GetRandomBytes(128);
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "INSERT INTO `User_Challenge`(`User_ID`, `Challenge`, `Valid_Duration`) VALUES (@User_ID,@Challenge,@Valid_Duration)";
                    MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                    MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(Challenge);
                    MySQLGeneralQuery.Parameters.Add("@Valid_Duration", MySqlDbType.DateTime).Value = CurrentDateTime;
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    MySQLGeneralQuery.ExecuteNonQuery();
                    ResultString = Convert.ToBase64String(Challenge);
                }
                else
                {
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "SELECT `Valid_Duration` FROM `User_Challenge` WHERE `User_ID`=@User_ID";
                    MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    DatabaseDateTime = DateTime.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                    MyTimeSpan = CurrentDateTime.Subtract(DatabaseDateTime);
                    if (MyTimeSpan.TotalMinutes <= 8)
                    {
                        MySQLGeneralQuery = new MySqlCommand();
                        MySQLGeneralQuery.CommandText = "SELECT `Challenge` FROM `User_Challenge` WHERE `User_ID`=@User_ID";
                        MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                        MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                        MySQLGeneralQuery.Prepare();
                        ResultString = MySQLGeneralQuery.ExecuteScalar().ToString();
                    }
                    else
                    {
                        MySQLGeneralQuery = new MySqlCommand();
                        MySQLGeneralQuery.CommandText = "DELETE FROM `User_Challenge` WHERE `User_ID`=@User_ID";
                        MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                        MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                        MySQLGeneralQuery.Prepare();
                        MySQLGeneralQuery.ExecuteNonQuery();
                        ResultString = "Error: This specified user had exceeded the valid duration.. Deleting the generated challenge";
                    }
                }
            }
            else
            {
                ResultString = "Error: This user doesn't exist";
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
            return ResultString;
        }
    }
}

﻿using ASodium;
using BCASodium;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MySql.Data.MySqlClient;
using SPKDSA_ServerApp.Helper;

namespace SPKDSA_ServerApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserOps : ControllerBase
    {
        private static MyOwnMySQLConnection myMyOwnMySQLConnection = new MyOwnMySQLConnection();

        [HttpGet]
        public String RegisterNormalUser(String User_ID, String Auth_PK, String Contact)
        {
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            String ExceptionString = "";
            String ResultString = "";
            int Count = 0;
            Byte[] SignedChallengeBytes = new Byte[] { };
            Byte[] ChallengeBytes = new Byte[] { };
            String ChallengeString = "";
            String SNode_API_IP_Address = "";
            String SNode_Auth_PK = "";
            Byte[] SNode_Auth_PK_Bytes = new Byte[] { };
            Boolean IsSNodePKNotChanged = true;
            DateTime CurrentDateTime = DateTime.UtcNow.AddHours(8);
            DateTime DatabaseDateTime = new DateTime();
            TimeSpan MyTimeSpan = new TimeSpan();
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery = new MySqlCommand();
            MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `Users` WHERE `User_ID`=@User_ID AND `Contact`=@Contact";
            MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
            MySQLGeneralQuery.Parameters.Add("@Contact", MySqlDbType.Text).Value = Contact;
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
            if (Count == 0)
            {
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "INSERT INTO `Users`(`User_ID`, `Contact`,`Auth_PK`) VALUES (@User_ID,@Contact,@Auth_PK)";
                MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                MySQLGeneralQuery.Parameters.Add("@Contact", MySqlDbType.Text).Value = Contact;
                MySQLGeneralQuery.Parameters.Add("@Auth_PK", MySqlDbType.Text).Value = Auth_PK;
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                MySQLGeneralQuery.ExecuteNonQuery();
                ResultString = "Success: This user has been registered..";
            }
            else
            {
                ResultString = "Error: This user existed..";
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
            return ResultString;
        }

        [HttpGet("UserLogin")]
        public String UserLogin(String User_ID, String SignedChallenge)
        {
            MySqlCommand MySQLGeneralQuery = new MySqlCommand();
            String ExceptionString = "";
            String ResultString = "";
            int Count = 0;
            Byte[] SignedChallengeBytes = new Byte[] { };
            Byte[] ChallengeBytes = new Byte[] { };
            String ChallengeString = "";
            String Auth_PK = "";
            Byte[] Auth_PK_Bytes = new Byte[] { };
            DateTime CurrentDateTime = DateTime.UtcNow.AddHours(8);
            DateTime DatabaseDateTime = new DateTime();
            TimeSpan MyTimeSpan = new TimeSpan();
            DateTime OldValidDT = new DateTime();
            myMyOwnMySQLConnection.LoadConnection(ref ExceptionString);
            MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `Users` WHERE `User_ID`=@User_ID";
            MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
            MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
            MySQLGeneralQuery.Prepare();
            Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
            if (Count == 1)
            {
                //In future need to verify locally with the signed records from authorized users of this node..
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT `Auth_PK` FROM `Users` WHERE `User_ID`=@User_ID";
                MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                Auth_PK = MySQLGeneralQuery.ExecuteScalar().ToString();
                Auth_PK_Bytes = Convert.FromBase64String(Auth_PK);
                SignedChallengeBytes = Convert.FromBase64String(SignedChallenge);
                if (Auth_PK_Bytes.Length == 32)
                {
                    ChallengeBytes = SodiumPublicKeyAuth.Verify(SignedChallengeBytes, Auth_PK_Bytes);
                }
                else
                {
                    ChallengeBytes = SecureED448.GetMessageFromSignatureMessage(Auth_PK_Bytes, SignedChallengeBytes, new Byte[] { });
                }
                MySQLGeneralQuery = new MySqlCommand();
                MySQLGeneralQuery.CommandText = "SELECT COUNT(*) FROM `User_Challenge` WHERE `Challenge`=@Challenge AND `User_ID`=@User_ID";
                MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(ChallengeBytes);
                MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                MySQLGeneralQuery.Prepare();
                Count = int.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                if (Count == 1)
                {
                    MySQLGeneralQuery = new MySqlCommand();
                    MySQLGeneralQuery.CommandText = "SELECT `Valid_Duration` FROM `User_Challenge` WHERE `Challenge`=@Challenge AND `User_ID`=@User_ID";
                    MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(ChallengeBytes);
                    MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                    MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                    MySQLGeneralQuery.Prepare();
                    DatabaseDateTime = DateTime.Parse(MySQLGeneralQuery.ExecuteScalar().ToString());
                    MyTimeSpan = CurrentDateTime.Subtract(DatabaseDateTime);
                    if (MyTimeSpan.TotalMinutes < 8)
                    {
                        MySQLGeneralQuery = new MySqlCommand();
                        MySQLGeneralQuery.CommandText = "DELETE FROM `User_Challenge` WHERE `Challenge`=@Challenge AND `User_ID`=@User_ID";
                        MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(ChallengeBytes);
                        MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                        MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                        MySQLGeneralQuery.Prepare();
                        MySQLGeneralQuery.ExecuteNonQuery();
                        ResultString = "Success: This user can login..";
                    }
                    else
                    {
                        ResultString = "Error: This verified challenge had expired.. deleting now..";
                        MySQLGeneralQuery = new MySqlCommand();
                        MySQLGeneralQuery.CommandText = "DELETE FROM `User_Challenge` WHERE `Challenge`=@Challenge AND `User_ID`=@User_ID";
                        MySQLGeneralQuery.Parameters.Add("@Challenge", MySqlDbType.Text).Value = Convert.ToBase64String(ChallengeBytes);
                        MySQLGeneralQuery.Parameters.Add("@User_ID", MySqlDbType.Text).Value = User_ID;
                        MySQLGeneralQuery.Connection = myMyOwnMySQLConnection.MyMySQLConnection;
                        MySQLGeneralQuery.Prepare();
                        MySQLGeneralQuery.ExecuteNonQuery();
                    }
                }
                else
                {
                    ResultString = "Error: This verified challenge no longer exists..";
                }
            }
            else
            {
                ResultString = "Error: This end user does not exist";
            }
            myMyOwnMySQLConnection.MyMySQLConnection.Close();
            myMyOwnMySQLConnection.ClearConnectionString();
            return ResultString;
        }
    }
}

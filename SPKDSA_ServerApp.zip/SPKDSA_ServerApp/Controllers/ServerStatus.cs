﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace SPKDSA_ServerApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ServerStatus : ControllerBase
    {
    }
}
